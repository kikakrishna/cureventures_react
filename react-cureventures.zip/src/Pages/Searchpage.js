import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import curelogo from './page-asset/Cure-Ventures.png'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import 'bootstrap/dist/css/bootstrap.min.css';
import Searchbar from './Components/Searchbar';

import './Searchpage.css'

const darkTheme = createTheme({
    palette: {

        primary: {
            main: '#fff',
        },
    },
});

const styles = {
    "&.MuiButton-root": {
        color: "grey",

    },
    "&.MuiButton-text": {
        color: "grey"
    },
    "&.MuiButton-contained": {
        color: "yellow"
    },
    "&.MuiButton-outlined": {
        color: "lightgrey"
    },
    "&.MuiButtonBase-root": {
        borderRadius: "20px",
        border: "1px grey",
        border: "1px grey solid",
        padding: "5px 9px 5px 5px",
        fontSize: "12px"
    }
};


export default function Searchpage() {
    return (
        <div className='Searchpagecontent'>
            <ThemeProvider theme={darkTheme}>
                <Box sx={{ flexGrow: 1 }}>
                    <AppBar position="static">
                        <Toolbar>
                            <div className='searchnavcontent'>
                                <IconButton
                                    size="large"
                                    edge="start"
                                    color="inherit"
                                    aria-label="menu"
                                    sx={{ mr: 2 }}
                                >
                                    <img src={curelogo} />

                                </IconButton>
                            </div>


                            {/* <div className='searchnavcontent'>
                               <p>Target Report</p> 
                                <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                                    Target Report
                                </Typography>
                            </div>
                            <Button color="inherit">Lorem ipsum</Button> */}
                            <Button color="inherit">Lorem ipsum</Button>
                            <Button color="inherit">Lorem ipsum</Button>
                            <Button color="inherit">Lorem ipsum</Button>

                        </Toolbar>
                    </AppBar>
                </Box>
            </ThemeProvider>
            <div className='containercontent'>
                <Container>

                    <Row >
                        {/* <Col> </Col> */}
                        <Col lg={12}>
                            <div className='searchmaincontent'>
                                <p1>Lorem Ipsum is simply text</p1><br /><br />
                                <p2>Lorem Ipsum is simply dummy text of the printing and typesetting <br /> industry.
                                    Lorem Ipsum has been the industry's standard dummy </p2>


                                <Searchbar />

                                {/* <Button sx={serachstyles} variant="outlined">Search</Button> */}




                                <ul>
                                    <li className='topicbutton'>
                                        Topics:
                                    </li>
                                    <li className='topicbutton'>
                                        <Button sx={styles} variant="outlined">Lorem ipsum</Button>
                                    </li>
                                    <li className='topicbutton'>
                                        <Button sx={styles} variant="outlined">Lorem ipsum</Button>

                                    </li>
                                    <li className='topicbutton'>
                                        <Button sx={styles} variant="outlined">Lorem ipsum</Button>

                                    </li>
                                    <li className='topicbutton'>
                                        <Button sx={styles} variant="outlined">Lorem ipsum</Button>

                                    </li>
                                    <li className='topicbutton'>
                                        <Button sx={styles} variant="outlined">Lorem ipsum</Button>

                                    </li>
                                </ul>
                            </div>

                        </Col>
                        {/* <Col> </Col> */}
                    </Row>
                </Container>
            </div>

        </div>

    );
}

// import Container from 'react-bootstrap/Container';
// import Row from 'react-bootstrap/Row';
// import Col from 'react-bootstrap/Col';
// // import 'bootstrap/dist/css/bootstrap.min.css';
// function Searchpage() {
//   return (
//     <Container>
//       <Row>
//         <Col sm={8}>sm=8</Col>
//         <Col sm={4}>sm=4</Col>
//       </Row>
//       <Row>
//         <Col sm>sm=true</Col>
//         <Col sm>sm=true</Col>
//         <Col sm>sm=true</Col>
//       </Row>
//     </Container>
//   );
// }

// export default Searchpage;