import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Curenavbar from './Components/Curenavbar'
import Tabcomponent from './Components/Tabcomponent';
import Topnavcure from './Components/Topnavcure';
import Accordiancompo from './Components/Accordiancompo';
import Checkboxcontent from './Components/Checkboxcontet';
import Geneticconstraint from './Components/Geneticconstraint';
import Graphql from './Graphql';

const darkTheme = createTheme({
    palette: {

        primary: {
            main: '#ffffff',
        },
    },
});

// function formatAsPercent(num) {
//     return new Intl.NumberFormat('default', {
//         style: 'percent',
//         minimumFractionDigits: 0,
//         maximumFractionDigits: 0,
//     }).format(num / 100);

//     console.log(formatAsPercent(25.49)); // 👉️ "25%"
//     console.log(formatAsPercent(25.5));
// }

// console.log(formatAsPercent(25.49)); // 👉️ "25%"
// console.log(formatAsPercent(25.5));






export default function Curedashboard() {


   
    return (
        <div>
            <Topnavcure />
            <Curenavbar />
            <Checkboxcontent />
            {/* <Graphql /> */}
            {/* <formatAsPercent /> */}
        </div>

    );
}