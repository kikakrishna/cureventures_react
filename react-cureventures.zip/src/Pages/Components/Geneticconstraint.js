import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import ProgressBar from 'react-bootstrap/ProgressBar';

import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import 'bootstrap/dist/css/bootstrap.min.css';

import './Geneticconstraint.css'


const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: "#F7F7F7",
        color: theme.palette.common.black,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    }, "&.MuiTableCell-root": {
        textAlign: "center"
    }
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    }, "&.MuiTableCell-root": {
        textAlign: "center"
    }
}));

function createData(exp, obs, oe, score, constraintType) {
    return { exp, obs, oe, score, constraintType };
}

const rows = [
    createData('34.5080', 32, "0.93(0.70-1.25)", 0.335570000, "sin"),
    createData('34.5080', 32, "0.93(0.70-1.25)", 0.335570000, "mis"),
    createData('34.5080', 32, "0.93(0.70-1.25)", 0.335570000, "lof"),
];

function createDatabottom(speciesName, targetGeneSymbol, queryPercentageIdentity, targetPercentageIdentity, homologyType, value) {
    return { speciesName, targetGeneSymbol, queryPercentageIdentity, targetPercentageIdentity, homologyType };
}

const bottomrows = [
    createDatabottom('Chimpanzee', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "10"),
    createDatabottom('Mouse', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "20"),
    createDatabottom('Guinea Pig', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "30"),
    createDatabottom('Pig - Duroc', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "40"),
    createDatabottom('Rabbit', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "50"),
    createDatabottom('Dog', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "60"),
    createDatabottom('Tropical clawed frog', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "70"),
    createDatabottom('Zebrafish', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "80"),
    createDatabottom('Macaque', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "90"),
    createDatabottom('Macaque', "KRAS", 89.3617, 88.8889, "ortholog_one2one", "90"),

];



export default function Geneticconstraint() {



    // const index = 100;

    const getProgressValue = (index) => {
        let totalRecords = 10;
        
        let result = index + 50 / totalRecords;
        // index = 100;
        // let result = index - 10 ;
        console.log("result--------"+result)

        return result;

    }





    return (
        <div className='geneticconstrainttable'>
            <h5>Genetic Constraint</h5>

            <div>

                <Row>
                    <Col>
                        <div className='tabletitle'>
                            <h6>gnomAD Variation</h6>
                        </div>
                    </Col>
                </Row>


                <Row>
                    <Col></Col>
                    <Col lg={11}>
                        <div className='tableone'>
                            <TableContainer component={Paper}>
                                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                    <TableHead>
                                        <TableRow>
                                            <StyledTableCell>exp</StyledTableCell>
                                            <StyledTableCell align="right">obs</StyledTableCell>
                                            <StyledTableCell align="right">oe</StyledTableCell>
                                            <StyledTableCell align="right">Score</StyledTableCell>
                                            <StyledTableCell align="right">Constrain type</StyledTableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {rows.map((row) => (
                                            <StyledTableRow key={row.exp}>
                                                <StyledTableCell component="th" scope="row">
                                                    {row.exp}
                                                </StyledTableCell>
                                                <StyledTableCell align="right">{row.obs}</StyledTableCell>
                                                <StyledTableCell align="right">{row.oe}</StyledTableCell>
                                                <StyledTableCell align="right">{row.score}</StyledTableCell>
                                                <StyledTableCell align="right">{row.constraintType}</StyledTableCell>
                                            </StyledTableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </div>

                    </Col>
                    <Col></Col>
                </Row>

            </div>

            <div className='contraintbottomrow'>

                <Row>
                    <Col>
                        <div className='tabletitle'>
                            <h6>Gene homology</h6>
                        </div>

                    </Col>
                </Row>
                <Row>
                    <Col></Col>
                    <Col lg={11}>
                        <div className='tableone'>
                            <TableContainer component={Paper}>
                                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                    <TableHead>
                                        <TableRow>
                                            <StyledTableCell>
                                                <span class="answered">speciesName</span>
                                            </StyledTableCell>
                                            <StyledTableCell align="right">targetGeneSymbol</StyledTableCell>
                                            <StyledTableCell align="right">queryPercentageIdentity</StyledTableCell>
                                            <StyledTableCell align="right">targetPercentageIdentity</StyledTableCell>
                                            <StyledTableCell align="right">homologyType</StyledTableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {bottomrows.map((row, index) => (

                                            <StyledTableRow key={row.speciesName}>
                                                <StyledTableCell component="th" scope="row">
                                                    {row.speciesName}
                                                </StyledTableCell>
                                                <StyledTableCell align="right">

                                                    <span>

                                                        <ProgressBar variant="success"

                                                            now={getProgressValue(index)}

                                                        />


                                                    </span>


                                                    {row.targetGeneSymbol}
                                                </StyledTableCell>

                                                <StyledTableCell align="right">{row.queryPercentageIdentity}</StyledTableCell>
                                                <StyledTableCell align="right">{row.targetPercentageIdentity}</StyledTableCell>
                                                <StyledTableCell align="right">{row.homologyType}</StyledTableCell>
                                            </StyledTableRow>
                                        ))}

                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </div>

                    </Col>
                    <Col></Col>
                </Row>


            </div>

        </div>

    );
}