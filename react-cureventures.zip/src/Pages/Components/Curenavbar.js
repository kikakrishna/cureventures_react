import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Stack from '@mui/material/Stack';
import dna from './Assets/Dna-blue.png'

import './Curenavbar.css'

const darkTheme = createTheme({
    palette: {

        primary: {
            main: '#ffffff',

        },
    },
});

const typo = {
    "&.MuiTypography-root": {
        marginTop: "-38px !important",
        flexGrow: 1,
        fontWeight: "bold",
    },
};


export default function Curenavbar() {
    return (
        <div>
            <Stack spacing={2} sx={{ flexGrow: 1 }}>
                <ThemeProvider theme={darkTheme}>

                    <Box sx={{ flexGrow: 1 }}>
                        <AppBar position="static">
                            <Toolbar>
                                <IconButton
                                    size="large"
                                    edge="start"
                                    color="inherit"
                                    aria-label="menu"
                                    sx={{ mr: 2 }}
                                >
                                    <img className='dnaimage' src={dna} />
                                </IconButton>
                                <Typography sx={typo}>
                                    KRAS
                                </Typography>
                                {/* <Button color="inherit">Login</Button> */}
                            </Toolbar>
                            <div className='navdisablecontent'>
                                <p><span className='navdisable'>Ensemble:</span> ENSG00000133703  <span className='navdisable'>| UniProt:</span> P01116 <span className='navdisable'>| Genecards:</span> KRAS  <span className='navdisable'>| HGNC:</span> KRAS <span className='navdisable'>| Project Score:</span> SIDG13960</p>
                            </div>

                        </AppBar>
                    </Box>

                </ThemeProvider>
            </Stack>

        </div>

    );
}