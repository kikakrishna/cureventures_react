import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';
import Backdrop from '@mui/material/Backdrop';
import { useState, useEffect } from 'react';
import Multiselect from 'multiselect-react-dropdown';
import Expression from './Expression';
import Geneticconstraint from './Geneticconstraint';
import Geneticassociation from './Geneticassociation';
import Essentiality from './Essentiality';
import Mouseko from './Mouseko';
import './Checkboxcontent.css'


export default function Checkboxcontent() {

    const [isloading, setisloading] = useState(false)
    const [data1, setdata] = useState([]);

    // useEffect(() => {
    //     //Runs on the first render
    //     //And any time any dependency value changes
    //   }, [data]);

    const [food, setFood] = useState([
        {
            value: 1,
            lable: "Ensemble"
        },
        {
            value: 2,
            lable: "UniProt"
        },
        {
            value: 3,
            lable: "GeneCards"
        },
        {
            value: 4,
            lable: "HGNC"
        },
        {
            value: 5,
            lable: "ProjectScore"
        },
    ]);

    var name = [
        {
            value: 1,
            lable: "Expression"
        },
        {
            value: 2,
            lable: "Genetic constraint"
        },
        {
            value: 3,
            lable: "Genetic association"
        },
        {
            value: 4,
            lable: "Mouse KO and known AEs"
        },
        {
            value: 5,
            lable: "Essentiality"
        },

    ]

    const onSelect = (selectedList, selectedItem) => {
        setisloading(!isloading)

        setTimeout(() => {
            var data = [...data1];
            data.push(selectedItem)

            console.log("eventselect" + JSON.stringify(selectedItem))
            setTimeout(() => {
                console.log("selected------>" + JSON.stringify(data))

            }, 0);

            setdata(data)
            setisloading(false)
        }, 500);

    }

    const onRemove = (selectedList, removedItem) => {
        setisloading(!isloading)


        setTimeout(() => {

            var data = [...data1];

            console.log("inside calling" + JSON.stringify(removedItem))

            //  setdata([]);

            //   setdata(data1.filter((i)=>(i.value !== selectedList[0].value)))
            console.log("before data1" + JSON.stringify(data1))

            const index = data1.findIndex(prod => prod.value === removedItem.value); //use id instead of index



            console.log('indexvalue' + index)

            if (index > -1) { //make sure you found it

                setdata(prevState => prevState.splice(index, 1));
            }


            setTimeout(() => {
                setdata(data1)
                console.log("remove afterrrrrrrrrrr--->" + JSON.stringify(data1))
            }, 0);
            setisloading(false)

        }, 500);


        //  let filteredArray = data.filter(item => item !== selectedList.value)

        //data=[];
        //setdata(filteredArray)

        // data=selectedList

        // console.log("event================remove=>" + JSON.stringify(selectedList))
        // setTimeout(() => {

        //     console.log("remove--->" + JSON.stringify(data))


        //     setdata(data)
        //     console.log("remove afterrrrrrrrrrr--->" + JSON.stringify(data1))
        // }, 1000);



    }

    // if (data == 1) {
    //     return (
    //         <div>

    //             <h2>hai</h2>
    //          <Ensemble />

    //         </div>

    //     )
    // }

    const handleToggle = () => {
        setisloading(!isloading)
    };

    const handleClose = () => {
        setisloading(false);
    };


    return (

        <div>
            {/* <Multiselect
                isObject={false}
                onRemove={(event) => {
                    console.log(event);
                }}
                onSelect={(event) => {
                    console.log(event);
                }}
                options={food}
                selectedValues={[]}
                showCheckbox
            /> */}


            < Multiselect
                placeholder="+ Add Report"
                options={name}
                displayValue="lable"
                showCheckbox={true}
                selectedValues={[]}
                onSelect={onSelect}
                onRemove={onRemove}
                value="value"
                id="value"
            />

            <Button
                onClick={handleToggle}
            />


            {isloading &&
                <Backdrop
                    sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={isloading}
                    onClick={handleClose}
                >
                    <CircularProgress color="inherit" />

                </Backdrop>}

            {data1.map((value, index) =>
                <div key={value.value}>

                    {value.value == 1 &&
                        <Expression key={value.value} />}

                    {value.value == 2 &&
                        <Geneticconstraint key={value.value} />}

                    {value.value == 3 &&
                        <Geneticassociation key={value.value} />}

                    {value.value == 4 &&
                        <Mouseko key={value.value} />}

                    {value.value == 5 &&
                        <Essentiality key={value.value} />}
                </div>
            )}

            {/* {data == 1 &&
                <Expression />}

            {data == 2 &&
                <Geneticconstraint />}

            {data == 3 &&
                <Geneticassociation />} */}
            {/* <h2>{data}</h2> */}
            {/* <Ensemble data={data} /> */}


        </div >



    );



}