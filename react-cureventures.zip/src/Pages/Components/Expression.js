import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useState, useEffect } from 'react';
import topchart from './Assets/topgraph.png'
import bottomchart from './Assets/Bottomgraph.png'
import './Expression.css'

export default function Expression(data) {
    // const { data } = props;
    // const [value, setValues] = useState('')


    useEffect(() => {
        console.log('tesstdtadtdtw' + JSON.stringify(data))
        // let s = {props}
        // setValues(s) 
    }, [data]);


    return (
        <div className='ensemblecontent'>
            <img src={topchart} />
            <img src={bottomchart} />

            {/* <h2> {props.data[0].value} </h2>  */}
            {/* <h2>hai</h2> */}
            {/* <h1>{value.data}</h1> */}

            {/* {props.data.map(({ value, lable }, index) => <li key={index}>Keyword: {value}, Frequency: {lable}</li>)} */}



            {/* {data.map((value, key) =>
                <div>{value.value}</div>
            )} */}

            {/* {data.map((datas,key) => <div>{datas.value}</div>)} */}
            {/* data.map((value,key) =>         <div>{value.status}</div>
                       <div>{value.count}</div> 
                   ) */}
            Expression
        </div>

    );


}