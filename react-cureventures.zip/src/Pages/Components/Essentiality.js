import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';


export default function Essentiality() {
    return (
        <div>
            <h2>Essentiality</h2>

        </div>

    );
}