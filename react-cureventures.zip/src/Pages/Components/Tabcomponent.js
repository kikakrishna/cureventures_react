import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import './Tabcomponent.css'

function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div>
            <div
                role="tabpanel"
                hidden={value !== index}
                id={`simple-tabpanel-${index}`}
                aria-labelledby={`simple-tab-${index}`}
                {...other}
            >
                {value === index && (
                    <Box sx={{ p: 3 }}>
                        <Typography>{children}</Typography>
                    </Box>
                )}
            </div>
        </div>

    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}


const theme = createTheme({
    typography: {
        h1: {
            textalign: "center",
            fontSize: 18,
            fontWeight: 600,
            color: "#324A7B",
            marginTop: "5px",
        },

    },
});
export default function Tabcomponent() {

    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (

        <div className='tabcontent'>
            <ThemeProvider theme={theme}>
                <Box sx={{ width: '100%' }}>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                        <Tabs value={value} onChange={handleChange}>
                            <Tab label="Expression" {...a11yProps(0)} />
                            <Tab label="Genetic constraint" {...a11yProps(1)} />
                            <Tab label="Genetic association" {...a11yProps(2)} />
                            <Tab label="Interaction" {...a11yProps(3)} />
                            <Tab label="Mouse KO and kknown AEs" {...a11yProps(4)} />
                            <Tab label="Essentiality" {...a11yProps(5)} />

                        </Tabs>
                    </Box>
                    <TabPanel value={value} index={0}>
                        Expression
                    </TabPanel>
                    <TabPanel value={value} index={1}>
                        Genetic constraint
                    </TabPanel>
                    <TabPanel value={value} index={2}>
                        Genetic association
                    </TabPanel>
                    <TabPanel value={value} index={3}>
                        Interaction
                    </TabPanel>
                    <TabPanel value={value} index={4}>
                        Mouse KO and kknown AEs
                    </TabPanel>
                    <TabPanel value={value} index={5}>
                        Essentiality
                    </TabPanel>
                </Box>
            </ThemeProvider>

        </div>

    );
}