import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';


export default function Mouseko() {
    return (
        <div>

            <h2> Mouse KO  and known AEs</h2>

        </div>

    );
}