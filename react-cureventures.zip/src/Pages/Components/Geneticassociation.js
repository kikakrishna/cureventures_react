import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import 'bootstrap/dist/css/bootstrap.min.css';

import './Geneticassociation.css'




const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: "#F7F7F7",
        color: theme.palette.common.black,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
    },
    "&.MuiTableCell-root": {
        textAlign: "center"
    }
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
        border: 0,
    },
    "&.MuiTableCell-root": {
        textAlign: "center"
    }
}));


function createDatatop(exp, obs, oe, score, constraintType) {
    return { exp, obs, oe, score, constraintType };
}



function createDatamiddle(exp, obs, oe, score, constraintType) {
    return { exp, obs, oe, score, constraintType };
}

const rows = [
    createDatamiddle('34.5080', 32, "0.93(0.70-1.25)", 0.335570000, "sin"),
    createDatamiddle('34.5080', 32, "0.93(0.70-1.25)", 0.335570000, "mis"),
    createDatamiddle('34.5080', 32, "0.93(0.70-1.25)", 0.335570000, "lof"),
];

function createDatabottom(speciesName, targetGeneSymbol, queryPercentageIdentity, targetPercentageIdentity, homologyType) {
    return { speciesName, targetGeneSymbol, queryPercentageIdentity, targetPercentageIdentity, homologyType };
}

const bottomrows = [
    createDatabottom('Chimpanzee', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Mouse', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Guinea Pig', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Pig - Duroc', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Rabbit', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Dog', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Tropical clawed frog', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Zebrafish', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),
    createDatabottom('Macaque', "KRAS", 89.3617, 88.8889, "ortholog_one2one"),

];



export default function Geneticassociation() {
    return (
        <div>
            <div className='associationtabletop'>
                <h5>Genetic associations</h5>


                <Row>
                    <Col>
                        <div className='Pagetitle'>
                            <h6>Gene Burden Estimates from WES</h6>

                        </div>
                    </Col>
                </Row>

                <Row>
                    <Col></Col>
                    <Col lg={11}>
                        <div className='associationtableone'>
                            <TableContainer component={Paper}>
                                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                    <TableHead>
                                        <TableRow>
                                            <StyledTableCell>Disease</StyledTableCell>
                                            <StyledTableCell align="right">Disease Id</StyledTableCell>
                                            <StyledTableCell align="right">Cohort</StyledTableCell>
                                            <StyledTableCell align="right">Ancestry</StyledTableCell>
                                            <StyledTableCell align="right">Allelic Requirement</StyledTableCell>
                                            <StyledTableCell align="right">Cases with QV</StyledTableCell>
                                            <StyledTableCell align="right">Total Cases</StyledTableCell>
                                            <StyledTableCell align="right">Odds Ratio</StyledTableCell>
                                            <StyledTableCell align="right">Beta</StyledTableCell>
                                            <StyledTableCell align="right">P-value</StyledTableCell>
                                            <StyledTableCell align="right">PMID</StyledTableCell>

                                        </TableRow>
                                    </TableHead>
                                    <TableBody>

                                        <StyledTableRow >
                                            <StyledTableCell component="th" scope="row">
                                                ...
                                            </StyledTableCell>

                                        </StyledTableRow>

                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </div>

                    </Col>
                    <Col></Col>
                </Row>


            </div>

            <div className='associationtablemiddle'>

                <Row>
                    <Col>
                        <div className='Pagetitle'>
                            <h6>Human GWAS associations</h6>

                        </div>
                    </Col>
                </Row>
                <Row>
                    <Col></Col>
                    <Col lg={11}>
                        <div className='associationtableone'>
                            <TableContainer component={Paper}>
                                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                    <TableHead>
                                        <TableRow>
                                            <StyledTableCell>exp</StyledTableCell>
                                            <StyledTableCell align="right">obs</StyledTableCell>
                                            <StyledTableCell align="right">oe</StyledTableCell>
                                            <StyledTableCell align="right">Score</StyledTableCell>
                                            <StyledTableCell align="right">Constrain type</StyledTableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {rows.map((row) => (
                                            <StyledTableRow key={row.exp}>
                                                <StyledTableCell component="th" scope="row">
                                                    {row.exp}
                                                </StyledTableCell>
                                                <StyledTableCell align="right">{row.obs}</StyledTableCell>
                                                <StyledTableCell align="right">{row.oe}</StyledTableCell>
                                                <StyledTableCell align="right">{row.score}</StyledTableCell>
                                                <StyledTableCell align="right">{row.constraintType}</StyledTableCell>
                                            </StyledTableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </div>

                    </Col>
                    <Col></Col>
                </Row>


            </div>

            <div className='associationtablebottom'>

                <Row>
                    <Col>
                        <div className='Pagetitle'>
                            <h6>Clinvar associations</h6>

                        </div>

                    </Col>
                </Row>
                <Row>
                    <Col></Col>
                    <Col lg={11}>
                        <div className='associationtableone'>
                            <TableContainer component={Paper}>
                                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                    <TableHead>
                                        <TableRow>
                                            <StyledTableCell>speciesName</StyledTableCell>
                                            <StyledTableCell align="right">targetGeneSymbol</StyledTableCell>
                                            <StyledTableCell align="right">queryPercentageIdentity</StyledTableCell>
                                            <StyledTableCell align="right">targetPercentageIdentity</StyledTableCell>
                                            <StyledTableCell align="right">homologyType</StyledTableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {bottomrows.map((row) => (
                                            <StyledTableRow key={row.speciesName}>
                                                <StyledTableCell component="th" scope="row">
                                                    {row.speciesName}
                                                </StyledTableCell>
                                                <StyledTableCell align="right">{row.targetGeneSymbol}</StyledTableCell>
                                                <StyledTableCell align="right">{row.queryPercentageIdentity}</StyledTableCell>
                                                <StyledTableCell align="right">{row.targetPercentageIdentity}</StyledTableCell>
                                                <StyledTableCell align="right">{row.homologyType}</StyledTableCell>
                                            </StyledTableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </div>

                    </Col>
                    <Col></Col>
                </Row>


            </div>




        </div>

    );
}