import * as React from 'react';
import { styled, alpha } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import InputBase from '@mui/material/InputBase';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import Button from '@mui/material/Button';


const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    //   '&:hover': {
    //     backgroundColor: alpha(theme.palette.common.white, 0.25),
    //   },
    marginLeft: '110',
    width: '50%',
    [theme.breakpoints.up('sm')]: {
        marginLeft: theme.spacing(48),
        width: '40%',
        borderRadius: "25px",
        backgroundColor: "#fff",
        color: "black",
        marginTop: "10px",
        marginBottom: "10px"
    },

}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
        padding: theme.spacing(1, 1, 1, 0),
        // vertical padding + font size from searchIcon
        paddingLeft: `calc(1em + ${theme.spacing(4)})`,
        transition: theme.transitions.create('width'),
        width: '100%',
        [theme.breakpoints.up('sm')]: {
            width: '50ch',
            '&:focus': {
                width: '20ch',
            },
            '&::placeholder': {
                textOverflow: 'ellipsis !important',
                color: 'black'
            }
        },
    },
}));


const serachstyles = {
    "&.MuiButton-root": {
        border: "none",
        backgroundColor: '#273F57',
        borderRadius: '25px',
        padding: '4px 36px',
        color: "#fff",
    },
    "&.MuiButton-text": {
        color: "grey"
    },
    "&.MuiButton-contained": {
        color: "yellow"
    },
    "&.MuiButton-outlined": {
        color: "brown"
    }
};

export default function Searchbar() {
    return (
        <Box sx={{ flexGrow: 1 }}>


            <Search>
                <SearchIconWrapper>
                    <SearchIcon />
                </SearchIconWrapper>
                <StyledInputBase
                    placeholder="Search…"
                    inputProps={{ 'aria-label': 'search' }}
                />
            </Search>
            <div className='searchbtn'>
                <Button sx={serachstyles} >Search</Button>

            </div>


        </Box>
    );
}
